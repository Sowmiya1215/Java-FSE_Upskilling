import java.util.List;

record Person(String name, int age) {}

public class RecordDemo {
    public static void main(String[] args) {

        Person p1 = new Person("John", 25);
        Person p2 = new Person("Alice", 18);
        Person p3 = new Person("Bob", 30);

        System.out.println(p1);

        List<Person> people = List.of(p1, p2, p3);

        people.stream()
              .filter(p -> p.age() >= 21)
              .forEach(System.out::println);
    }
}