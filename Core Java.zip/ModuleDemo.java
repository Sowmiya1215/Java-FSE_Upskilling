public class ModuleDemo {

    static class Utility {
        public static void greet() {
            System.out.println("Hello from Utility Class");
        }
    }

    public static void main(String[] args) {
        Utility.greet();
    }
}