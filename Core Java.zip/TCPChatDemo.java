import java.io.*;
import java.net.*;

public class TCPChatDemo {

    static class ServerThread extends Thread {
        public void run() {
            try {
                ServerSocket serverSocket = new ServerSocket(5000);
                Socket socket = serverSocket.accept();

                BufferedReader br = new BufferedReader(
                        new InputStreamReader(socket.getInputStream()));

                System.out.println("Server received: " + br.readLine());

                socket.close();
                serverSocket.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    static class ClientThread extends Thread {
        public void run() {
            try {
                Thread.sleep(1000);

                Socket socket = new Socket("localhost", 5000);

                PrintWriter pw = new PrintWriter(
                        socket.getOutputStream(), true);

                pw.println("Hello Server");

                socket.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        new ServerThread().start();
        new ClientThread().start();
    }
}