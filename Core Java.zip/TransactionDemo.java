import java.sql.*;

public class TransactionDemo {

    public static void transfer(Connection con,
                                int fromAcc,
                                int toAcc,
                                double amount) {

        try {
            con.setAutoCommit(false);

            PreparedStatement debit = con.prepareStatement(
                    "UPDATE accounts SET balance = balance - ? WHERE id=?");

            debit.setDouble(1, amount);
            debit.setInt(2, fromAcc);
            debit.executeUpdate();

            PreparedStatement credit = con.prepareStatement(
                    "UPDATE accounts SET balance = balance + ? WHERE id=?");

            credit.setDouble(1, amount);
            credit.setInt(2, toAcc);
            credit.executeUpdate();

            con.commit();

            System.out.println("Transfer Successful");
        }
        catch(Exception e) {
            try {
                con.rollback();
            } catch(Exception ex) {}

            System.out.println("Transfer Failed");
        }
    }
}